[![Jazzband](https://jazzband.co/static/img/jazzband.svg)](https://jazzband.co/)

This is a [Jazzband](https://jazzband.co/) project. By contributing you agree to abide
by the [Contributor Code of Conduct](https://jazzband.co/docs/conduct) and follow the
[guidelines](https://jazzband.co/docs/guidelines).
